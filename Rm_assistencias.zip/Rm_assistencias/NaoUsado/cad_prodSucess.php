<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css"> <!-- Incluindo o style.css -->
    <title>Cadastro Realizado</title>
</head>
<body>

<div class="cad_prod-form-container">
    <h2 class="cad_prod-title">Cadastro Realizado com Sucesso!</h2>
    <p>Seu produto foi cadastrado com sucesso.</p>
    <a href="index.php" class="cad_prod-submit">Voltar à Página Inicial</a>
</div>

</body>
</html>
<?php
echo "Página de sucesso carregada!";
exit(); // Para garantir que nada mais seja executado
?>
