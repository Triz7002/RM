<?php
include('sessao.php');

$id = $_GET['id'];
$conexao = mysqli_connect('localhost', 'root', '', 'assistencia_rm');
$sql = "SELECT * FROM produtos WHERE id=$id";
$executar = mysqli_query($conexao, $sql);
$res = mysqli_fetch_array($executar);
$fechar = mysqli_close($conexao);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styleADM.css"> <!-- Incluindo o style.css -->
    <title>Atualizar Produto</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5; /* Fundo branco suave */
            color: #333; /* Cor do texto mais escura */
            margin: 0;
            padding: 20px; /* Espaçamento ao redor */
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh; /* Para ocupar toda a altura da página */
        }

        .update-form-container {
            background-color: #fff; /* Fundo branco para o formulário */
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1); /* Sombra leve */
            width: 400px; /* Largura do formulário */
            transition: box-shadow 0.3s;
        }

        .update-form-container:hover {
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.2); /* Efeito ao passar o mouse */
        }

        .form-group {
            margin-bottom: 15px; /* Espaço entre os grupos do formulário */
        }

        .form-label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        .form-input {
            width: calc(100% - 20px); /* Largura total menos o padding */
            padding: 10px;
            border: 1px solid #ccc; /* Borda cinza suave */
            border-radius: 5px; /* Bordas arredondadas */
            background-color: #f9f9f9; /* Fundo claro para os campos */
            box-sizing: border-box; /* Inclui padding e borda na largura */
        }

        .form-input:focus {
            border-color: #ff3333; /* Cor de foco */
            outline: none; /* Remove o contorno padrão */
        }

        .form-submit {
            padding: 12px;
            background-color: #ff3333; /* Cor do botão */
            border: none;
            color: #fff; /* Cor do texto do botão */
            border-radius: 5px; /* Bordas arredondadas */
            cursor: pointer; /* Muda o cursor para pointer */
            font-size: 18px; /* Tamanho do texto do botão */
            transition: background-color 0.3s; /* Transição suave na cor de fundo */
            width: 100%; /* Botão ocupa toda a largura disponível */
        }

        .form-submit:hover {
            background-color: #ff6666; /* Cor ao passar o mouse */
        }
    </style>
</head>
<body>

<div class="update-form-container">
    <h2>Atualizar Produto</h2>
    <form action="atualizar.php" method="post">
        <div class="form-group">
            <label class="form-label">Id produto:</label>
            <input class="form-input" type="text" name="id" value="<?php echo $res['id'];?>" readonly>
        </div>
        <div class="form-group">
            <label class="form-label">Nome do produto:</label>
            <input class="form-input" type="text" name="nome" value="<?php echo $res['nome'];?>" required>
        </div>
        <div class="form-group">
            <label class="form-label">Quantidade:</label>
            <input class="form-input" type="number" name="quant" value="<?php echo $res['quant'];?>" required>
        </div>
        <div class="form-group">
            <label class="form-label">Valor:</label>
            <input class="form-input" type="text" name="valor" value="<?php echo $res['valor'];?>" required>
        </div>
        <div class="form-group">
            <input class="form-submit" type="submit" value="Atualizar">
        </div>
    </form>
</div>

</body>
</html>
