<?php
include("sessao.php");
include("topo.php");  // Inclui o topo com a verificação de administrador

// Verifica se o formulário foi enviado usando o método POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Usa isset para evitar warnings
    $nome = isset($_POST['nome']) ? $_POST['nome'] : '';
    $quant = isset($_POST['quant']) ? $_POST['quant'] : '';
    $valor = isset($_POST['valor']) ? $_POST['valor'] : '';
    $cat = isset($_POST['cat']) ? $_POST['cat'] : '';
    $nomeArq = isset($_FILES['arquivo']['name']) ? basename($_FILES['arquivo']['name']) : '';
    
    // Diretório de upload
    $uploaddir = 'C:/xampp/htdocs/Rm_assistencias/imagens/'; 
    $uploadfile = $uploaddir . $nomeArq;

    // Conexão com o banco de dados
    $conexao = mysqli_connect('localhost', 'root', '', 'assistencia_rm');

    // Inserção no banco de dados
    $sql = "INSERT INTO produtos (nome, quant, valor, categoria, foto) 
            VALUES ('$nome', $quant, $valor, '$cat', '$nomeArq')";
    
    // Executar a inserção
    $executar = mysqli_query($conexao, $sql);

    // Tenta mover o arquivo apenas se a inserção for bem-sucedida
    if ($executar) {
        move_uploaded_file($_FILES['arquivo']['tmp_name'], $uploadfile);
        // Redirecionar para a página inicial após o cadastro
        header("Location: inicial.php");
        exit(); // Importante para evitar que o código continue a ser executado após o redirecionamento
    }

    // Fechar a conexão
    mysqli_close($conexao);
} 

include('final.html'); // Inclui o rodapé
?>
