<?php
session_start(); // Inicia a sessão

// Finaliza a sessão
$_SESSION = array(); // Limpa todas as variáveis de sessão
session_destroy(); // Destrói a sessão

include('topo.php');  // Inclui o topo com a navegação
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logout - RM Assistência Técnica</title>
    <link rel="stylesheet" href="style.css"> <!-- Link para o arquivo style.css -->
</head>
<body>
    <div class="logout-main">
        <div class="logout-navbar">
            <div class="icon">
                <h2 class="logo">RM</h2>
            </div>
            <div class="logout-menu">
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="login.php">Login</a></li>
                </ul>
            </div>
        </div>

        <div class="logout-content">
            <h1>Logout realizado com sucesso!</h1>
            <p><a class="logout-btn" href="login.php">Entrar novamente</a></p>
        </div>
    </div>
    <div class="logout-message">
        <p>Você foi desconectado com sucesso.</p>
    </div>
</body>
</html>
