<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pg inicial RM</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <div class="main">
        <div class="navbar">
            <div class="icon">
                <h2 class="logo">RM</h2>
            </div>

            <div class="menu">
                <ul>
                    <li><a href="login.php">LOGIN</a></li>
                    <li><a href="cadastro.php">CADASTRE-SE</a></li>
                </ul>
            </div>

        </div> 

        <div class="content">
            <h1><span>RM</span><br>ASSISTÊNCIA TÉCNICA <br>DE CELULARES</h1>
            <p class="par">Na RM Assistência Técnica, somos especializados em conserto e manutenção<br>
            de dispositivos eletrônicos. Oferecemos um atendimento rápido e eficiente,<br>
            garantindo a satisfação dos nossos clientes.</p>
        </div>
    </div>
    
    <script src="https://unpkg.com/ionicons@5.4.0/dist/ionicons.js"></script>
</body>
</html>

<!--  content, menu, logo,icon, navbar, main, par  -->