<?php
session_start();  // Inicia a sessão
include('topo.php');  // Inclui o cabeçalho e a navegação

// Verifica se o usuário está autenticado
if (!isset($_SESSION['id'])) {
    die("Você precisa estar logado para adicionar produtos ao carrinho. <a href='acessar.php'>Logar</a>");
}

// Obtém os IDs do produto e do cliente
$id_prod = isset($_GET['id']) ? intval($_GET['id']) : 0;  // Sanitize the input
$id_cli = $_SESSION['id'];

// Conecta ao banco de dados
$con = mysqli_connect('localhost', 'root', '', 'assistencia_rm');

// Verifica a conexão
if (!$con) {
    die("Conexão falhou: " . mysqli_connect_error());
}

// Prepara e executa a consulta para adicionar o produto ao carrinho
$sql = "INSERT INTO carrinho (id_cli, id_prod) VALUES (?, ?)";
$stmt = mysqli_prepare($con, $sql);
mysqli_stmt_bind_param($stmt, 'ii', $id_cli, $id_prod);

if (mysqli_stmt_execute($stmt)) {
    echo "Produto inserido no carrinho";
} else {
    echo "Erro ao adicionar produto ao carrinho: " . mysqli_error($con);
}

// Fecha a conexão
mysqli_stmt_close($stmt);
mysqli_close($con);

echo "<br><a href='ver_produtos.php'>Comprar mais</a>";
include('final.html');  // Inclui o rodapé
?>
