<div class="navbar">
    <div class="icon">
        <h2 class="logo">RM</h2>
    </div>

    <div class="menu">
        <ul>
            <li><a href="inicial.php">INÍCIO</a></li>
            <?php
            if(isset($_SESSION['adm'])) {
                if($_SESSION['adm'] == 1) {
                    // Links para administrador
                    echo '<li><a href="cad_produto.php">Cadastrar Produtos</a></li>';
                    echo '<li><a href="listar.php">Gerenciar Produtos</a></li>';
                } else {
                    // Links para cliente
                    echo '<li><a href="carrinho.php">Carrinho</a></li>';
                }
                echo '<li><a href="logout.php">Sair</a></li>';
            } else {
                // Links quando o usuário não está logado
                echo '<li><a href="login.php">Login</a></li>';
            }
            ?>
        </ul>
    </div>
</div>
