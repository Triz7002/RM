<?php
session_start();  

if (!isset($_SESSION['nome'])) {
    echo "Você precisa estar logado para acessar esta página. <a href='login.php'>Logar</a>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Produtos - RM Assistência Técnica</title>
    <link rel="stylesheet" href="style.css"> <!-- Incluindo o arquivo CSS externo -->
    <script>
        function addToCart(id, button) {
            fetch('add_carrinho.php?id=' + id)
                .then(response => {
                    if (response.ok) {
                        button.textContent = 'Adicionado ao Carrinho';
                        setTimeout(() => {
                            button.textContent = 'Comprar';
                        }, 2000);
                    } else {
                        console.error('Erro ao adicionar o produto ao carrinho.');
                    }
                })
                .catch(error => console.error('Erro:', error));
        }
    </script>
</head>
<body>
    <?php include('topo.php'); ?>

    <div class="produtos-main">
        <div class="produtos-content">
            <h1>Produtos Disponíveis</h1>
            <div class="produtos-product-list">
                <?php
                // Conecta ao banco de dados
                $con = mysqli_connect('localhost', 'root', '', 'assistencia_rm');
                
                // Verifica a conexão
                if (!$con) {
                    die("Erro ao conectar ao banco de dados: " . mysqli_connect_error());
                }
                
                // Consulta para obter os produtos
                $sql = "SELECT * FROM produtos ORDER BY nome ASC";
                $exe = mysqli_query($con, $sql);
                
                // Verifica se a consulta retornou resultados
                if (mysqli_num_rows($exe) > 0) {
                    while ($res = mysqli_fetch_assoc($exe)) {
                        $id = $res['id'];
                        $nome = htmlspecialchars($res['nome'], ENT_QUOTES, 'UTF-8'); // Protege contra XSS
                        $valor = number_format($res['valor'], 2, ',', '.');  // Formata o valor
                        $foto = $res['foto'];
                        echo "<div class='produtos-product-item'>
                            <img src='imagens/$foto' alt='Imagem de $nome'> 
                            <span>Produto: $nome</span><br>
                            <span>Preço: R$ $valor</span><br>
                            <button class='produtos-btn' style='background-color: #d10e0e; color: #fff; padding: 10px 20px; font-size: 18px; border: none; border-radius: 5px;' onclick='addToCart($id, this)'>Comprar</button>
                        </div>";
                    }
                } else {
                    echo "<p class='produtos-erro'>Nenhum produto encontrado.</p>";
                }
                
                mysqli_close($con);
                ?>
            </div>
        </div>
    </div>
</body>
</html>
