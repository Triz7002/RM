<?php
session_start();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro Realizado - RM Assistência Técnica</title>
    <link rel="stylesheet" href="style.css"> <!-- Adicionando o arquivo CSS -->
    <style>
        body {
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            margin: 0;
            background-color: black; /* Cor de fundo */
        }
        .sucesso-container {
            text-align: center;
            background-color: #fff; /* Cor do fundo da caixa */
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            width: 400px; /* Largura da caixa */
        }
        .sucesso-container h1 {
            color: #d10e0e; /* Cor do título */
        }
        .sucesso-container p {
            color: #555; /* Cor do texto */
            margin: 20px 0;
        }
        .sucesso-container a {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #d10e0e; /* Cor do botão */
            color: #fff; /* Cor do texto do botão */
            text-decoration: none;
            border-radius: 5px;
        }
        .sucesso-container a:hover {
            background-color: black; /* Cor do botão ao passar o mouse */
        }
    </style>
</head>
<body>

    <div class="sucesso-container">
        <h1>Cadastro Realizado!</h1>
        <p>Parabéns, seu cadastro foi realizado com sucesso.</p>
        <a href="login.php">Voltar ao Login</a>
    </div>

</body>
</html>
