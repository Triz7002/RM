<?php
session_start();
include('topo.php'); // Inclui o topo com a navegação

$nome = $_GET['nome'];      
$rua = $_GET['rua'];
$bairro = $_GET['bairro'];
$num_casa = $_GET['num_casa'];
$cep = $_GET['cep'];
$email = $_GET['email'];
$celular = $_GET['celular'];  
$senha = $_GET['senha'];

$conexao = mysqli_connect('localhost', 'root', '', 'assistencia_rm');

$sql = "INSERT INTO usuarios (nome, rua, bairro, num_casa, cep, login, celular, senha) 
        VALUES ('$nome', '$rua', '$bairro', '$num_casa', '$cep', '$email', '$celular', '$senha')";

$executar = mysqli_query($conexao, $sql);

// Redireciona para a página de sucesso
header("Location: sucesso.php");
exit();

mysqli_close($conexao);
?>
