<?php
include("sessao.php");

$conexao = mysqli_connect('localhost', 'root', '', 'assistencia_rm');
$sql = "SELECT * FROM produtos";
$executar = mysqli_query($conexao, $sql);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styleADM.css"> <!-- Incluindo o style.css -->
    <title>Listar Produtos</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            font-size: 16px;
            text-align: left;
        }

        th, td {
            padding: 12px;
            border: 1px solid #ddd;
        }

        th {
            background-color: #ff3333; /* Cor de fundo dos cabeçalhos */
            color: white; /* Cor do texto dos cabeçalhos */
        }

        tr:nth-child(even) {
            background-color: #f9f9f9; /* Cor de fundo das linhas pares */
        }

        tr:hover {
            background-color: #ffe6e6; /* Cor ao passar o mouse */
        }

        img {
            width: 50px;
            height: auto; /* Mantém a proporção da imagem */
            border-radius: 5px; /* Bordas arredondadas nas imagens */
        }

        a {
            color: #ff3333; /* Cor dos links */
            text-decoration: none; /* Remove o sublinhado */
        }

        a:hover {
            text-decoration: underline; /* Sublinha ao passar o mouse */
        }
    </style>
</head>
<body>

<div class="table-container">
    <h2>Lista de Produtos</h2>
    <table>
        <tr>
            <th>Id</th>
            <th>Imagem</th>
            <th>Nome</th>
            <th>Quantidade</th>
            <th>Valor</th>
            <th>Apagar</th>
            <th>Atualizar</th>
        </tr>
        <?php
        while ($resultado = mysqli_fetch_array($executar)) {
            $id = $resultado['id'];
            $nome = $resultado['nome'];
            $quant = $resultado['quant'];
            $valor = $resultado['valor'];
            $foto = $resultado['foto'];
            echo "<tr>
                    <td>$id</td>
                    <td><img src='imagens/$foto' alt='$nome'></td>
                    <td>$nome</td>
                    <td>$quant</td>
                    <td>$valor</td>
                    <td><a href='del_prod.php?id=$id'>Remover</a></td>
                    <td><a href='upd_prod.php?id=$id'>Atualizar</a></td>
                  </tr>";
        }
        ?>
    </table>
</div>

<?php
$fechar = mysqli_close($conexao);

?>
