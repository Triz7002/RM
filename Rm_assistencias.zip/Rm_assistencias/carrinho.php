<?php
session_start();  // Inicia a sessão

// Verifica se o usuário está autenticado
if (!isset($_SESSION['id'])) {
    echo "Você precisa estar logado para visualizar o carrinho. <a href='login.php'>Logar</a>";
    exit();
}

// Obtém o ID do cliente
$id_cli = $_SESSION['id'];

// Conecta ao banco de dados
$con = mysqli_connect('localhost', 'root', '', 'assistencia_rm');

// Verifica a conexão
if (!$con) {
    die("Conexão com o banco de dados falhou: " . mysqli_connect_error());
}


?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carrinho - RM Assistência Técnica</title>
    <link rel="stylesheet" href="style.css"> <!-- Verifique se o caminho está correto -->
</head>
<body>
    <div class="carrinho-main">
        <div class="carrinho-navbar">
            <div class="carrinho-logo">RM</div>
            <div class="carrinho-menu">
                <ul>
                    <li><a href="inicial.php">Home</a></li>
                    <li><a href="logout.php">Sair</a></li>
                </ul>
            </div>
        </div>

        <div class="carrinho-content">
            <h1>Seu Carrinho</h1>
            <div class="carrinho-items-container">
                <?php
                // Prepara e executa a consulta para obter os produtos do carrinho
                $sql = "SELECT carrinho.id_car, produtos.nome, produtos.valor, produtos.foto 
                        FROM carrinho 
                        JOIN produtos ON carrinho.id_prod = produtos.id 
                        WHERE carrinho.id_cli = ?";
                $stmt = mysqli_prepare($con, $sql);
                mysqli_stmt_bind_param($stmt, 'i', $id_cli);
                mysqli_stmt_execute($stmt);
                $result = mysqli_stmt_get_result($stmt);

                $total = 0;

                // Verifica se existem produtos no carrinho
                if (mysqli_num_rows($result) > 0) {
                    // Exibe os produtos do carrinho
                    while ($res = mysqli_fetch_array($result)) {
                        $id_car = $res['id_car'];
                        $nome = htmlspecialchars($res['nome'], ENT_QUOTES, 'UTF-8');  // Protege contra XSS
                        $valor = number_format($res['valor'], 2, ',', '.');  // Formata o valor para moeda
                        $total += $res['valor'];
                        $foto = $res['foto'];  // Supondo que a foto do produto está sendo armazenada

                        echo "<div class='carrinho-item'>
                                <img src='imagens/$foto' alt='$nome' class='produto-img'>  <!-- Mostra a imagem do produto -->
                                <div>Produto: $nome</div>
                                <div>Preço: R$ $valor</div>
                                <a href='del_carrinho.php?id=$id_car' class='remove-btn'>Remover</a>
                              </div>";
                    }
                } else {
                    echo "<p>Seu carrinho está vazio.</p>";
                }

                // Exibe o total
                $totalFormatted = number_format($total, 2, ',', '.');  // Formata o total para moeda
                echo "</div><div class='carrinho-total-container'>";
                echo "<div class='carrinho-total'>O valor total é: <b>R$ $totalFormatted</b></div>";

                echo "<div class='carrinho-actions'><a href='ver_produtos.php' class='buy-more-btn'>Comprar mais</a></div>";

                // Fecha a conexão
                mysqli_stmt_close($stmt);
                mysqli_close($con);
                ?>
            </div>
        </div>
    </div>
</body>
</html>
