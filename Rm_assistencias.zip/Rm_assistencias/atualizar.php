<?php
include('sessao.php');

$id = $_POST['id'];
$nome = $_POST['nome'];
$quant = $_POST['quant'];
$valor = $_POST['valor'];

$conexao = mysqli_connect('localhost', 'root', '', 'assistencia_rm');
$sql = "UPDATE produtos SET nome='$nome', quant=$quant, valor=$valor WHERE id=$id";
$executar = mysqli_query($conexao, $sql);

if ($executar) {
    // Redireciona para listar.php após a atualização
    header("Location: listar.php");
    exit(); // Encerra o script após o redirecionamento
} else {
    echo "Erro ao atualizar.";
}

$fechar = mysqli_close($conexao);
?>
