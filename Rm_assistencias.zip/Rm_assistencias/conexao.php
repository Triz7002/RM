<?php
$host = 'localhost';
$user = 'root';
$password = '';
$database = 'assistencia_rm';

$con = mysqli_connect($host, $user, $password, $database);

if (!$con) {
    die("Falha na conexão com o banco de dados: " . mysqli_connect_error());
}
?>
