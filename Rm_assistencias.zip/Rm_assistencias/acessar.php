<?php
session_start();  // Inicia a sessão
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - RM Assistência Técnica</title>
    <link rel="stylesheet" href="style.css"> <!-- Link para o CSS externo -->
    <script src="https://unpkg.com/ionicons@5.4.0/dist/ionicons.js"></script> <!-- Inclui Ionicons -->
</head>
<body>

<div class="main"> <!-- Container principal com fundo preto e altura total -->
    <div class="form"> <!-- Div centralizada para o formulário -->
        <h2>Faça Login Aqui</h2>
        <input type="email" name="email" placeholder="Digite seu e-mail">
        <input type="password" name="password" placeholder="Digite sua senha">
        <button class="btnn"><a href="#">Entrar</a></button>

        <p class="link">Não tem uma conta?<br>
            <a href="#">Cadastre-se aqui</a>
        </p>

    </div>
</div>

</body>
</html>
