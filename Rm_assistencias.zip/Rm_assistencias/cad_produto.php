<?php

include("sessao.php");

$con = mysqli_connect('localhost', 'root', '', 'assistencia_rm');

$sql = "SELECT * FROM categorias ORDER BY nome ASC";
$exe = mysqli_query($con, $sql);

?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styleADM.css"> <!-- Incluindo o style.css -->
    <title>Cadastrar Produto</title>
</head>
<body>

<div class="cad_prod-form-container">
    <h2 class="cad_prod-title">Cadastrar Produto</h2>
    <form action="inserir.php" method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label class="cad_prod-label">Escolher arquivo:</label>
            <input class="cad_prod-input" name="arquivo" type="file" required><br>
        </div>

        <div class="form-group">
            <label class="cad_prod-label">Nome do produto:</label>
            <input class="cad_prod-input" type="text" name="nome" required><br>
        </div>

        <div class="form-group">
            <label class="cad_prod-label">Quantidade:</label>
            <input class="cad_prod-input" type="number" name="quant" required><br>
        </div>

        <div class="form-group">
            <label class="cad_prod-label">Valor:</label>
            <input class="cad_prod-input" type="text" name="valor" required><br>
        </div>

        <div class="form-group">
            <label class="cad_prod-label">Categoria:</label>
            <select class="cad_prod-select" name="cat" required>
                <?php
                while ($res = mysqli_fetch_array($exe)) {
                    $id = $res['id'];
                    $nome = $res['nome'];
                    echo "<option value='$id'>$nome</option>";
                }
                ?>
            </select><br>
        </div>

        <input class="cad_prod-submit" type="submit" href="inicial.php" value="Cadastrar">
    </form>
</div>



</body>
</html>
