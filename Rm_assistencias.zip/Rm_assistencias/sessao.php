<?php
session_start();

if (!isset($_SESSION['nome']) || $_SESSION['nome'] == null) {
    header("Location: login.php");
    exit();
}

$nome = $_SESSION['nome'];
$adm = $_SESSION['adm'];
?>
