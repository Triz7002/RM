<?php
session_start();



// Verifica se o login-formulário foi enviado
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $login = $_POST['login'];
    $senha = $_POST['senha'];

    // Conexão com o banco de dados
    $conexao = mysqli_connect('localhost', 'root', '', 'assistencia_rm');
    if (!$conexao) {
        die('Falha na conexão com o banco de dados: ' . mysqli_connect_error());
    }

    // Protege contra SQL Injection usando prepared statements
    $stmt = $conexao->prepare("SELECT * FROM usuarios WHERE login = ? AND senha = ?");
    $stmt->bind_param('ss', $login, $senha);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();

    if ($res) {
        // Autenticação bem-sucedida
        $_SESSION['nome'] = $res['nome'];
        $_SESSION['id'] = $res['id'];
        $_SESSION['adm'] = $res['adm'];
        header('Location: inicial.php');
        exit();
    } else {
        // Falha na autenticação
        $login_erro = "Login e/ou senha incorretos!";
    }

    // Fecha a conexão
    $stmt->close();
    mysqli_close($conexao);
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - RM Assistência Técnica</title>
    <link rel="stylesheet" href="style.css"> <!-- Adicionando o arquivo CSS -->
</head>
<body>

    <div class="login-main">
        <div class="login-login-form-container">
            <div class="login-form">
                <h2>Login</h2>
                
                <!-- Exibe a mensagem de login-erro, caso exista -->
                <?php if (isset($login_erro)): ?>
                    <p class="login-erro"><?php echo $login_erro; ?></p>
                <?php endif; ?>

                <form action="" method="POST"> <!-- Corrigido para <form> -->
                    <input type="text" id="login" name="login" placeholder="Digite seu email" required>
                    <input type="password" id="senha" name="senha" placeholder="Digite sua senha" required>
                    <button type="submit" class="login-btnn">Entrar</button>
                    <p class="link">Não tem uma conta? <a href="cadastro.php">Cadastre-se aqui</a></p>
                </form>
            </div>
        </div>
    </div>

    <script src="https://unpkg.com/ionicons@5.4.0/dist/ionicons.js"></script>
</body>
</html>
