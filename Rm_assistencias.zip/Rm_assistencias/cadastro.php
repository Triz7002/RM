<?php
session_start();

?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Clientes - RM Assistência Técnica</title>
    <link rel="stylesheet" href="style.css"> <!-- Adicionando o arquivo CSS -->
</head>
<body>

    <div class="login-main">
        <div class="login-login-form-container">
            <div class="login-form">
                <h2>Cadastro de Clientes</h2>

                <form action="Ecommerce.php" method="GET">
                    <input type="text" name="nome" placeholder="Digite seu nome" required>
                    <input type="text" name="rua" placeholder="Digite sua rua" required>
                    <input type="text" name="bairro" placeholder="Digite seu bairro" required>
                    <input type="text" name="num_casa" placeholder="Número da casa" required>
                    <input type="text" name="cep" placeholder="Digite seu CEP" required>
                    <input type="text" name="celular" placeholder="Número de celular" required>
                    <input type="text" name="email" placeholder="Digite seu email" required>
                    <input type="password" name="senha" placeholder="Digite sua senha" required>
                    <button type="submit" class="login-btnn">Cadastrar</button>
                    <p class="link">Já tem uma conta? <a href="login.php">Entre aqui</a></p>
                </form>
            </div>
        </div>
    </div>

</body>
</html>
